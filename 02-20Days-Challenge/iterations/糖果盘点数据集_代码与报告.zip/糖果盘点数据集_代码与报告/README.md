# 桌面糖果盘点数据集与分类实验

用手机俯拍桌面糖果，判断画面中糖果是**少**还是**多**，同时区分**散装 / 连体 / 混战**三种形态，并在四种光照条件下评估鲁棒性。

## 目录结构

```
model/
├─ dataset/                 204 张原始照片，12 个中文场景目录
│  ├─ 正常光/{散装少量, 散装多量, 连体少量, 大混战}
│  ├─ 强光/{散装, 连体, 大混战}
│  ├─ 阴影/{散装, 连体, 混战}
│  └─ 弯折/{弯折, 弯折和散糖}
│
├─ count_tool/              全部代码
│  ├─ labels.py             从目录名解析标签 + 按时间戳聚类连拍组
│  ├─ features.py           预训练 ResNet18 提取 512 维特征
│  ├─ train_linear.py       三任务分组交叉验证（主实验）
│  ├─ train.py              端到端微调对照实验
│  ├─ make_figures.py       生成报告全部配图
│  ├─ 拍摄清单.md           采集时的场景清单
│  ├─ runs/report.json      全部实验指标
│  └─ figures/              报告配图
│
└─ 实验报告.md               完整报告（含数据体检、结果、失败分析）
```

## 快速开始

```bat
cd count_tool

python labels.py          :: 看数据集构成（12 场景 / 204 张 / 21 个独立组）
python features.py        :: 提特征，CPU 约 50 秒
python train_linear.py    :: 三任务交叉验证，约 10 秒
python make_figures.py    :: 出图
```

端到端微调对照（可选，CPU 约 5 分钟）：

```bat
python train.py --task amount --arch mobilenet_v3_small --size 192 --epochs 12 --folds 3
```

## 标签体系

目录名即标签，无需人工标注。`labels.py` 从路径解析出三个正交维度：

| 维度 | 取值 |
|---|---|
| `light` | normal / strong / shadow / bend |
| `form` | loose（散装）/ linked（连体）/ mixed（混战） |
| `amount` | few / medium / many |

## 主要结果

| 任务 | 张级准确率 | 组级准确率 | 多数类基线 |
|---|---|---|---|
| 少 vs 多（175 张 / 18 组） | 71.5% | **85.3%** | 50.9% |
| 散装/连体/混战（204 张 / 21 组） | 71.0% | **87.7%** | 34.8% |
| 四种光照（204 张 / 21 组） | 57.6% | **78.3%** | 33.8% |

「组级准确率」按连拍组多数投票，一组对应一堆糖，比张级更接近真实使用。详见 `实验报告.md`。

## 环境

Python 3.13 + PyTorch 2.12 (CPU) + torchvision 0.27 + scikit-learn + opencv + matplotlib。无需 GPU。

首次运行会下载 ImageNet 预训练权重（ResNet18 约 45 MB，MobileNetV3-Small 约 10 MB）。

## 一个重要提醒

数据集中 204 张照片只对应 **21 个独立连拍组**（同场景内相邻间隔 ≤45 秒视为同组）。任何划分都必须按组进行，若按张随机划分，验证集里会混入与训练集近乎相同的连拍帧，准确率会虚高十几个百分点。本仓库所有实验均使用 `GroupKFold`。
